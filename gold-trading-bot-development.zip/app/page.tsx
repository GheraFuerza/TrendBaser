'use client'

import { useState } from 'react'
import {
  Activity,
  AlertTriangle,
  ArrowDownRight,
  ArrowUpRight,
  BarChart3,
  Bell,
  CalendarClock,
  Check,
  ChevronDown,
  CircleHelp,
  Gauge,
  Layers3,
  Menu,
  Moon,
  Pause,
  Play,
  Radio,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Target,
  TrendingUp,
  Wallet,
  X,
  Zap,
} from 'lucide-react'

const filters = [
  { label: 'Trend', value: 'Bullish', detail: 'H1 EMA 20 > 50', icon: TrendingUp, tone: 'gold' },
  { label: 'Risk / trade', value: '1.0%', detail: 'Auto-sized by SL', icon: ShieldCheck, tone: 'green' },
  { label: 'Spread', value: '0.12', detail: 'Max allowed 0.35', icon: Activity, tone: 'green' },
  { label: 'Session', value: 'London · NY', detail: 'Open · 08:00–17:00 UTC', icon: CalendarClock, tone: 'blue' },
  { label: 'News', value: 'Clear', detail: 'Next high impact in 2h 14m', icon: Bell, tone: 'green' },
  { label: 'Correlation', value: 'Low', detail: 'DXY inverse · 0.31', icon: Layers3, tone: 'violet' },
]

const decisions = [
  { time: '09:42:18', title: 'BUY signal qualified', text: 'Trend, volatility and volume conditions aligned.', kind: 'buy', meta: 'Confidence 82%' },
  { time: '09:40:02', title: 'Spread check passed', text: 'Current spread 0.12 is below 0.35 maximum.', kind: 'pass', meta: 'XAUUSD' },
  { time: '09:32:44', title: 'No trade', text: 'Waiting for a clean pullback to the H1 EMA zone.', kind: 'wait', meta: 'Patience filter' },
  { time: '09:15:11', title: 'News filter passed', text: 'No high-impact USD events within the buffer window.', kind: 'pass', meta: 'Buffer ±30m' },
]

function Sparkline() {
  return (
    <svg viewBox="0 0 520 145" className="sparkline" role="img" aria-label="XAUUSD upward price chart">
      <defs>
        <linearGradient id="area" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor="#d4a84f" stopOpacity=".28" />
          <stop offset="100%" stopColor="#d4a84f" stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d="M0 119 C24 113 31 121 51 107 S80 92 97 99 S123 86 143 91 S160 71 184 78 S213 65 229 72 S250 54 273 61 S293 47 313 54 S342 42 356 48 S377 35 397 42 S414 27 433 34 S452 16 469 25 S494 12 520 7 V145 H0Z" fill="url(#area)" />
      <path d="M0 119 C24 113 31 121 51 107 S80 92 97 99 S123 86 143 91 S160 71 184 78 S213 65 229 72 S250 54 273 61 S293 47 313 54 S342 42 356 48 S377 35 397 42 S414 27 433 34 S452 16 469 25 S494 12 520 7" fill="none" stroke="#d4a84f" strokeWidth="2.5" />
      <circle cx="469" cy="25" r="4" fill="#f5d58a" />
    </svg>
  )
}

export default function Page() {
  const [running, setRunning] = useState(true)
  const [showAll, setShowAll] = useState(false)
  const [mobileNav, setMobileNav] = useState(false)

  return (
    <main className="app-shell">
      <aside className={`sidebar ${mobileNav ? 'mobile-open' : ''}`}>
        <div className="brand"><div className="brand-mark"><Zap /></div><span>aurum<span className="brand-dot">.</span></span></div>
        <div className="account-switcher"><span className="live-dot" /> <span>MT5 · Demo account</span><ChevronDown /></div>
        <nav aria-label="Primary navigation">
          <p className="nav-label">Workspace</p>
          <a className="nav-item active" href="#overview"><Gauge /> Overview</a>
          <a className="nav-item" href="#decisions"><Radio /> Decision log <span className="nav-count">4</span></a>
          <a className="nav-item" href="#performance"><BarChart3 /> Performance</a>
          <a className="nav-item" href="#risk"><ShieldCheck /> Risk controls</a>
          <p className="nav-label second">System</p>
          <a className="nav-item" href="#settings"><SlidersHorizontal /> Bot settings</a>
          <a className="nav-item" href="#help"><CircleHelp /> Documentation</a>
        </nav>
        <div className="sidebar-footer"><div className="avatar">TR</div><div><strong>Trading room</strong><span>Analyst workspace</span></div><ChevronDown /></div>
      </aside>

      <section className="content">
        <header className="topbar"><button className="icon-button menu-button" onClick={() => setMobileNav(!mobileNav)} aria-label="Toggle navigation"><Menu /></button><div className="breadcrumb"><span>Workspace</span><span>/</span><strong>XAUUSD Bot</strong></div><div className="top-actions"><span className="market-status"><i /> Market open</span><button className="icon-button" aria-label="Notifications"><Bell /></button><button className="avatar small">TR</button></div></header>
        <div className="page-wrap" id="overview">
          <div className="hero-row"><div><div className="eyebrow"><span className="pulse" /> Live monitoring</div><h1>XAUUSD command center</h1><p className="subtitle">Trend-first execution with every decision accounted for.</p></div><button className={`run-button ${running ? 'running' : 'paused'}`} onClick={() => setRunning(!running)}>{running ? <><Pause /> Pause bot</> : <><Play /> Resume bot</>}</button></div>

          <section className="quote-grid"><div className="quote-card primary-card"><div className="card-top"><div><span className="muted-label">XAUUSD · Gold / US Dollar</span><div className="price">2,658.42 <span className="price-change"><ArrowUpRight /> +0.84%</span></div></div><span className="timeframe">1H <ChevronDown /></span></div><div className="chart-wrap"><div className="chart-y"><span>2,670</span><span>2,650</span><span>2,630</span><span>2,610</span></div><Sparkline /></div><div className="chart-footer"><span>09:00</span><span>11:00</span><span>13:00</span><span>15:00</span><span>17:00 UTC</span></div></div><div className="metric-card"><div className="metric-icon green"><Wallet /></div><span className="muted-label">Today&apos;s P&amp;L</span><strong className="metric-value">+$184.60</strong><span className="metric-change positive">+1.84% <span>vs. balance</span></span><div className="metric-bar"><i /></div></div><div className="metric-card"><div className="metric-icon gold"><Target /></div><span className="muted-label">Risk deployed</span><strong className="metric-value">0.72%</strong><span className="metric-change"><span>of 1.00% max per trade</span></span><div className="risk-ring"><span>72%</span></div></div></section>

          <section className="section-block" id="risk"><div className="section-heading"><div><h2>Decision gates</h2><p>Pre-trade filters · evaluated in sequence</p></div><span className="all-clear"><Check /> 6 / 6 passing</span></div><div className="filter-grid">{filters.map(({ label, value, detail, icon: Icon, tone }) => <div className="filter-card" key={label}><div className={`filter-icon ${tone}`}><Icon /></div><div className="filter-copy"><span>{label}</span><strong>{value}</strong><small>{detail}</small></div><span className="check"><Check /></span></div>)}</div></section>

          <section className="lower-grid" id="decisions"><div className="panel decision-panel"><div className="panel-heading"><div><h2>Decision log</h2><p>Transparent reasoning from the last 30 minutes</p></div><button className="text-button" onClick={() => setShowAll(!showAll)}>{showAll ? 'Show less' : 'View all'} <ArrowUpRight /></button></div><div className="decision-list">{decisions.slice(0, showAll ? 4 : 3).map((item) => <div className="decision-row" key={item.time}><div className={`decision-symbol ${item.kind}`}>{item.kind === 'buy' ? <ArrowUpRight /> : item.kind === 'wait' ? <Pause /> : <Check />}</div><div className="decision-main"><div><strong>{item.title}</strong><span className="decision-time">{item.time} UTC</span></div><p>{item.text}</p></div><span className="decision-meta">{item.meta}</span></div>)}</div></div><div className="panel performance-panel" id="performance"><div className="panel-heading"><div><h2>Adaptive layer</h2><p>Performance-based adjustments</p></div><Sparkles className="sparkle" /></div><div className="adaptive-score"><div><span className="muted-label">Current confidence</span><strong>82<span>/100</span></strong></div><div className="score-gauge"><i /></div></div><div className="adjustment"><div className="adjustment-icon"><TrendingUp /></div><div><strong>Momentum is healthy</strong><p>Maintaining base risk at 1.0%. No adjustment required.</p></div></div><div className="stats-row"><div><span>Win rate</span><strong>68.4%</strong></div><div><span>Profit factor</span><strong>1.74</strong></div><div><span>Trades</span><strong>23</strong></div></div></div></section>
          <footer className="footer-note"><span><AlertTriangle /> Trading involves risk. This bot is an execution framework, not financial advice.</span><span>Last sync: 09:42:18 UTC</span></footer>
        </div>
      </section>
    </main>
  )
}
